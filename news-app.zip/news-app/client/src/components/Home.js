import React from "react";
import "./Home.css";
const Home = () => {
  return (
    <><div>
      <div className="home">
        Welcome To News App
      </div>
    </div>
    </>
  );
};

export default Home;
